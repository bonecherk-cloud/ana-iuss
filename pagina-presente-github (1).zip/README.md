# Página de presente — redirecionamento por clique

Página estática, responsiva e leve. A pessoa precisa tocar no presente ou no botão para abrir o destino. Não usa cookies, analytics, banco de dados ou redirecionamento automático.

## Destino atual
`https://www.crownbot.com.br/natyvampirinha`

O destino aparece no `index.html` em três lugares (dois links e o texto visível). Para manter tudo consistente, altere os três lugares caso algum dia precise mudar o endereço.

## Publicar no GitHub Pages (grátis)
1. Entre em https://github.com e faça login.
2. Clique em **New repository**.
3. Dê um nome, por exemplo `pagina-presente`, selecione **Public** e crie o repositório.
4. Descompacte este ZIP no computador.
5. No repositório, clique em **Add file → Upload files** e envie `index.html` e `README.md` (não envie a pasta externa; envie os arquivos dentro dela).
6. Clique em **Commit changes**.
7. Abra **Settings → Pages**.
8. Em **Build and deployment**, escolha **Deploy from a branch**; selecione `main` e `/ (root)` e salve.
9. Aguarde a publicação e abra o endereço exibido na área Pages. Normalmente será `https://SEU-USUARIO.github.io/pagina-presente/`.

## É grátis para sempre?
GitHub Pages está disponível no plano Free para repositórios públicos, mas não existe garantia de hospedagem “para sempre”. O site pode ficar no ar por muito tempo enquanto a conta, o repositório, as políticas e os limites do serviço forem mantidos. O GitHub também informa que Pages é voltado principalmente a sites de apresentação de projetos e não a hospedagem gratuita de negócios/serviços comerciais. Se esta página for parte central de uma campanha comercial de captação de leads, confira os termos do serviço e considere uma hospedagem adequada para esse uso.

## Sobre aprovação em plataformas
Nenhuma página garante aprovação no TikTok. Este modelo deixa o destino visível antes do clique e não tenta ocultá-lo de revisores. Confira as regras atuais da plataforma e assegure que a página de destino e a oferta sejam compatíveis com elas.

## Observações
- Não é possível tornar o redirecionamento “impossível de alterar”: quem tem acesso de escrita ao repositório pode modificar os arquivos. Proteja a conta com autenticação de dois fatores e limite colaboradores.
- O GitHub Pages publica arquivos estáticos; não inclui banco de dados nem painel administrativo.
